<?php

$nombre = $_POST["nombre"];
$documento = $_POST["documento"];
$edad = $_POST["edad"];

if($edad>=18)
{
    print "Tome guaro <br> ";
}

else
{
    print "Eche pa la casa <br> ";
}

print $nombre." - ".$documento. " - ".$edad;

?>