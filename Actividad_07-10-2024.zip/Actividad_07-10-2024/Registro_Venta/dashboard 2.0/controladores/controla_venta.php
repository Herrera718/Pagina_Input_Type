<?php

$valor_a_pagar = $_POST["valor_a_pagar"];
$edad = $_POST["edad"];
$porcentaje = $valor_a_pagar * 0.20; 
$descuento = $valor_a_pagar - $porcentaje;


if($edad<=0)
{
    die("edad no valida");
}

if($valor_a_pagar <=0)
{
    die("valor no valido");
}

if($edad>60)
{
    print "Usted obtiene un descuento del 20% <br> ";
    print $descuento;
}else{
    print "El valor de su compra es <br>";
    print $valor_a_pagar;
} 



?>