<a button class="btn btn-primary w-100 py-2" type="submit" href="Iniciar_Sesion.php">Iniciar sesion</button> </a>
<br>
    <br>
        <font color="#1877f2"> <a href="https://www.facebook.com/login/identify/?ctx=recover&ars=facebook_login&from_login_screen=0" target="_blank">¿Olvidaste tu cuenta?</a>   </font>
      </label>
      
      <br>
      <br>
      <div class="separator"> <font color="grey">o</font></div>
      <br>
      <a button class="btn-1 w-50 py-2" type="submit" href="crear_cuenta.php">
        <font color="white">Crear cuenta nueva </font>
      </button> </a>