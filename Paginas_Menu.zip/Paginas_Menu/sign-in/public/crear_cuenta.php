<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Iniciar sesion en Facebook</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sign-in/">

    

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">

<link href="../../assets/dist/css/bootstrap.min.css" rel="stylesheet">
<center>
    <style>

      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      body { 
        font-family: Arial, Helvetica, sans-serif;
        background-color: #f8f9fa;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      } 



      .form-content {
        background: linear-gradient(
        50deg,
        rgb(255, 255, 255) 30%,
        rgb(255, 255, 255));
        
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        padding: 30px;
        width: 415px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(158, 158, 158, 0.493);
      }

      @media (min-width: 76px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgb(0, 0, 0);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(255, 0, 0, 0.1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #5500ff;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }

      .bd-mode-toggle {
        z-index: 1500;
      }

      .bd-mode-toggle .dropdown-menu .active .bi {
        display: block !important;
      }

      .btn-primary-1{
        background-color: rgb(0, 170, 0);
      }

      .btn-1{
        background-color: rgb(0, 170, 0);
        border: 0;
        border-radius: 5px;
      }

      .separator {
      display: flex;
      align-items: center;
      text-align: center;
    }

    .separator::before,
    .separator::after {
      content: '';
      flex: 1;
      border-bottom: 1px solid #ccc;
    }

    .separator::before {
      margin-right: 10px;
    }

    .separator::after {
      margin-left: 10px;
    }

    input , textarea {
    
    background-color: #ffffffce;
    
}



    </style>

    
    <!-- Custom styles for this template -->
    
    
    

    
<main class="form-signin w-100 m-auto">
  <img class="mb-4" src="../img/Facebook.png" alt="" width="250" height="50">
  <div class="form-content">
  <form>
    
    <font color="black"> <h1 class="h3 mb-3 fw-normal">Por favor ingrese los datos que se le solicitan </h1> </font>

    
      <input type="text" id="inombres" class="form-control" name="nombres" placeholder="Nombres"> 
      <label for="inombres">  </label>
    
    
      <input type="text" id="iapellidos" class="form-control" name="apellidos" placeholder="Apellidos">
      <label for="iapellidos"></label>
    
    
      <input type="email" id="iemail" class="form-control" name="correo" placeholder="Numero de movil o correo electronico"> 
      <label for="iemail">  </label>
    
    
      <input type="password" id="icontraseña" class="form-control" name="contraseña" placeholder="Contraseña nueva">
      <label for="icontraseña"></label>

      <input type="date" id="inacimiento" class="form-control" name="nacimiento" placeholder="Fecha de nacimiento">
      <label for="inacimiento"></label>

      <br>
       <label for="genero" class="form-label">Genero</label> 
            <select id="genero" class="form-control" name="genero">
            <option value="Muj">Mujer</option>
              <option value="Hom">Hombre</option>
              <option value="Per">Personalizado</option>
            </select>


    <br>
    <p class="fs-7 text-body-secondary">Es posible que las personas que usan nuestro servicio hayan subido tu información de 
      contacto a Facebook. <font color="#1877f2"> <a href="https://www.facebook.com/help/637205020878504" target="_blank">Mas información</a>.</font>
    </p>

    <p class="fs-7 text-body-secondary">  Al hacer clic en Registrarte, aceptas las 
      <font color="#1877f2"> <a href="https://www.facebook.com/legal/terms/update" target="_blank">Condiciones</a>, </font> la 
      <a href="https://www.facebook.com/privacy/policy/?entry_point=data_policy_redirect&entry=0" target="_blank">Politica de privacidad</a> 
      </font> y la <a href="https://www.facebook.com/privacy/policies/cookies/?entry_point=cookie_policy_redirect&entry=0" 
      target="_blank">Politica de cookies</a>.</font>Es posible que te enviemos notificaciones por SMS, que podrás desactivar cuando quieras. 
    </p>

    <a button class="btn-1 w-50 py-2" type="submit" href="cuenta_creada.php">
        <font color="white">Registrarte </font>
      </button> </a>    
    </div>
    

     
  </form>
</div>
</main>
<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

    </body>
  </center>
</html>
