<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Temu | Finalizar la compra </title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/checkout/">

    

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">

<link href="../../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }

      .bd-mode-toggle {
        z-index: 1500;
      }

      .bd-mode-toggle .dropdown-menu .active .bi {
        display: block !important;
      }



      .btn-anaranjado {
      background-color: #fb7701;
      color: white;
      
      padding: 10px 20px;
      border-radius: 20px;
      
    }
    
    .btn-anaranjado:hover {
      background-color: darkorange;
    }

    .btn-blanco {
            background-color: white;
            color: black;
            padding: 10px 20px;
            border: 2px solid grey;
            border-radius: 25px; 
            font-size: 16px;
            
            
    }









    </style>

    
    <!-- Custom styles for this template -->
    

    <div class="dropdown position-fixed bottom-0 end-0 mb-3 me-3 bd-mode-toggle">
      <button class="btn btn-bd-primary py-2 dropdown-toggle d-flex align-items-center"
              id="bd-theme"
              type="button"
              aria-expanded="false"
              data-bs-toggle="dropdown"
              aria-label="Toggle theme (auto)">
        <svg class="bi my-1 theme-icon-active" width="1em" height="1em"><use href="#circle-half"></use></svg>
        <span class="visually-hidden" id="bd-theme-text">Toggle theme</span>
      </button>
      <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="bd-theme-text">
        <li>
          <button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="light" aria-pressed="false">
            <svg class="bi me-2 opacity-50" width="1em" height="1em"><use href="#sun-fill"></use></svg>
            Light
            <svg class="bi ms-auto d-none" width="1em" height="1em"><use href="#check2"></use></svg>
          </button>
        </li>
        <li>
          <button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="dark" aria-pressed="false">
            <svg class="bi me-2 opacity-50" width="1em" height="1em"><use href="#moon-stars-fill"></use></svg>
            Dark
            <svg class="bi ms-auto d-none" width="1em" height="1em"><use href="#check2"></use></svg>
          </button>
        </li>
        <li>
          <button type="button" class="dropdown-item d-flex align-items-center active" data-bs-theme-value="auto" aria-pressed="true">
            <svg class="bi me-2 opacity-50" width="1em" height="1em"><use href="#circle-half"></use></svg>
            Auto
            <svg class="bi ms-auto d-none" width="1em" height="1em"><use href="#check2"></use></svg>
          </button>
        </li>
      </ul>
    </div>

    
<div class="container">
  
  <main>
    

    <div class="row g-5">
      <div class="col-md-5 col-lg-4 order-md-last">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
        
          <br>
          <br>
          
          
          
        </h4>
        <ul class="list-group mb-3">
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              
              <thead>
                <tr>
                  
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><svg class="bi" width="24" height="24"><use xlink:href="#check"/></svg></td>
                  <th scope="row" class="text-start"><h6>Resumen del pedido</h6> </th>
                </tr>
            </div>
            
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
            <div class="row g-3">
            <div class="col-sm-6">
              <h6 class="my-0"><input type="text" id="icupon" class="form-control" name="cupon" placeholder="Ingresa el codigo con cupón"> 
              <label for="icupon">  </label> </h6>
              
            </div>



            <div class="col-sm-6">
            <button type="button" class="btn-blanco" >Aplicar</button> </a>
            </div>
            
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Total de articulos:$</h6> 
              <p style="color: #fb7701;" class="my-0">Descuento de articulo(s) de articulos:-$</p>
              <h6 class="my-0">Subtotal:$</h6>
              
            </div>
            
          </li>
          <li class="list-group-item d-flex justify-content-between bg-body-tertiary">
            
              <h6 class="my-0">Envío: </h6><p style="color: #0a8852;" class="my-0">GRATIS</p>
              
            
            
          </li>
          <li class="list-group-item d-flex justify-content-between">
            <span>Total del pedido:$</span>
            
          </li>
          <br>
          <a button type="button" class="btn-anaranjado" href="index.php"><center><h5>Finalizar compra</center></button> </a></h5>

        </ul>

        
        </form>
      </div>

      
      <div class="col-md-7 col-lg-8"> 
        



              <div class="col-12">
                <br>
                <br>
                <h1>Metodos de pago </h1>
                
              <label>
                <input type="radio" name="grupo1" value="opcion1"> Tarjeta
              </label>
              <br>
              <label>
                <input type="radio" name="grupo1" value="opcion2"> PSE
              </label>
              <br>
              <label>
                <input type="radio" name="grupo1" value="opcion3"> Google Pay
              </label>
              <br>
              <label>
                <input type="radio" name="grupo1" value="opcion3"> Nequi
              </label>
            </div>


          </form>

          <hr class="my-4">

          
  </main>

  
</div>
<script src="../../assets/dist/js/bootstrap.bundle.min.js"></script>

    <script src="../js/checkout.js"></script></body>
</html>