<div class="row g-5">
      <div class="col-md-5 col-lg-4 order-md-last">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
        
          <br>
          <br>
          
          <a button type="button" class="btn-anaranjado" href="continuar_compra.php">Continuar para pagar</button> </a>
          
        </h4>
        <ul class="list-group mb-3">
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              
              <thead>
                <tr>
                  
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><svg class="bi" width="24" height="24"><use xlink:href="#check"/></svg></td>
                  <th scope="row" class="text-start"><h6>Temu protege la información de tu tarjeta</h6> </th>
                </tr>
            </div>
            
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Temu sigue el Estándar de Seguridad de Datos para la Industria de Tarjeta de Pago 
                (PCI DSS) cuando maneja datos de tarjetas</h6>
              
            </div>
            
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">La información de la tarjeta es segura y no está comprometida</h6>
              
            </div>
            
          </li>
          <li class="list-group-item d-flex justify-content-between bg-body-tertiary">
            
              <h6 class="my-0">Todos los datos están cifrados</h6>
              
            
            
          </li>
          <li class="list-group-item d-flex justify-content-between">
            <span>Temu nunca vende la información de tu tarjeta</span>
            
          </li>
        </ul>

        
        </form>
      </div>