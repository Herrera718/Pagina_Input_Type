<div class="d-flex flex-column flex-md-row align-items-center pb-0 mb-6 border-bottom">
      <img class="mb-4" src="../img/google_one.png" alt="" width="210" height="40">

      <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="Descripcion_general.php">Descripcion general</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="Al_premium.php">Al Premium</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="+funciones_google.php">Mas funciones en Google</a>
        <a class="py-2 link-body-emphasis text-decoration-none" href="planes_precios.php">Planes y precios</a>
      </nav>
    </div>